const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageActionRow} = require('discord.js')
const config = require('../../config.json');

module.exports = {

name: 'help',
description: '📱 [Painel] Exibe meu painel de ajuda.',
type: ApplicationCommandType.ChatInput,

run: async (client, interaction, args) => {

    let embed = new EmbedBuilder()
    .setThumbnail(`${config.client.foto}`)
    .setTitle(`${config.client.title}`)
    .setDescription(`
    
    <:Suporte:1079496179160715375> **Comandos Gerais:**
    <:Fixado:1076181716420538490> | /help - Exibe está mensagem
    <:Fixado:1076181716420538490> | /add-stock - Adicionar estoque aos produtos!
    <:Fixado:1076181716420538490> | /criar - Adicionar novo produto a venda!
    <:Fixado:1076181716420538490> | /set - Exibir produto para compra!
    <:Fixado:1076181716420538490> | /gerenciar - Gerenciar um produto da loja
    <:Fixado:1076181716420538490> | /limpardm - Limpa a sua dm
    
    🛡️ **Comandos de Moderação:**
    <:Fixado:1076181716420538490> | /lock - Tranca o Canal Selecionado
    <:Fixado:1076181716420538490> | /unlock - Destranca o Canal Selecionado
    
    ___Outros:___
    > **Entre no meu servidor de suporte** [aqui](https://discord.gg/RjkwEPQ3SF)`)
    .setColor(config.client.embed)

interaction.reply({ embeds: [embed]})
}
}